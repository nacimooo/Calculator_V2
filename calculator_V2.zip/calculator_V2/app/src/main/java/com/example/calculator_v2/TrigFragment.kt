package com.example.calculator_v2

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import com.example.calculator_v2.databinding.FragmentTrigBinding



class TrigFragment : Fragment(R.layout.fragment_trig) {
    private lateinit var binding: FragmentTrigBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = FragmentTrigBinding.inflate(layoutInflater)
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = super.onCreateView(inflater, container, savedInstanceState)

        val btnSin = view?.findViewById<Button>(R.id.buttonSin)
        val btnCos = view?.findViewById<Button>(R.id.buttonCos)
        val btnTan = view?.findViewById<Button>(R.id.buttonTan)
        val btnCot = view?.findViewById<Button>(R.id.buttonCot)
        val btnCsc = view?.findViewById<Button>(R.id.buttonCsc)
        val btnSec = view?.findViewById<Button>(R.id.buttonSec)

        btnSin?.setOnClickListener {
            (requireActivity() as MainActivity).isAdd = 0
            (requireActivity() as MainActivity).isMul = 0
            (requireActivity() as MainActivity).isDiv = 0
            (requireActivity() as MainActivity).isMod = 0
            (requireActivity() as MainActivity).isRoot = 0
            (requireActivity() as MainActivity).isMin = 1
            (requireActivity() as MainActivity).isDigit = 0
            (requireActivity() as MainActivity).isDec = 0
            (requireActivity() as MainActivity).numToDiv = 10.0
            (requireActivity() as MainActivity).isSin = 1
            (requireActivity() as MainActivity).isCos = 0
            (requireActivity() as MainActivity).isTan = 0
        }
        btnCos?.setOnClickListener {
            (requireActivity() as MainActivity).isAdd = 0
            (requireActivity() as MainActivity).isMul = 0
            (requireActivity() as MainActivity).isDiv = 0
            (requireActivity() as MainActivity).isMod = 0
            (requireActivity() as MainActivity).isRoot = 0
            (requireActivity() as MainActivity).isMin = 1
            (requireActivity() as MainActivity).isDigit = 0
            (requireActivity() as MainActivity).isDec = 0
            (requireActivity() as MainActivity).numToDiv = 10.0
            (requireActivity() as MainActivity).isSin = 0
            (requireActivity() as MainActivity).isCos = 1
            (requireActivity() as MainActivity).isTan = 0
        }
        btnTan?.setOnClickListener {
            (requireActivity() as MainActivity).isAdd = 0
            (requireActivity() as MainActivity).isMul = 0
            (requireActivity() as MainActivity).isDiv = 0
            (requireActivity() as MainActivity).isMod = 0
            (requireActivity() as MainActivity).isRoot = 0
            (requireActivity() as MainActivity).isMin = 1
            (requireActivity() as MainActivity).isDigit = 0
            (requireActivity() as MainActivity).isDec = 0
            (requireActivity() as MainActivity).numToDiv = 10.0
            (requireActivity() as MainActivity).isSin = 0
            (requireActivity() as MainActivity).isCos = 0
            (requireActivity() as MainActivity).isTan = 1
        }


        return view
    }

}
