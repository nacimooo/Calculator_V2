package com.example.calculator_v2

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import com.example.calculator_v2.databinding.FragmentBasicBinding


class BasicFragment : Fragment(R.layout.fragment_basic) {
    private lateinit var binding2: FragmentBasicBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding2 = FragmentBasicBinding.inflate(layoutInflater)
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = super.onCreateView(inflater, container, savedInstanceState)

        val btnPlus = view?.findViewById<Button>(R.id.buttonSin)
        val btnMin = view?.findViewById<Button>(R.id.buttonCos)
        val btnMul = view?.findViewById<Button>(R.id.buttonTan)
        val btnDiv = view?.findViewById<Button>(R.id.buttonCot)
        val btnMod = view?.findViewById<Button>(R.id.buttonCsc)
        val btnRoot = view?.findViewById<Button>(R.id.buttonRoot)

        btnPlus?.setOnClickListener {
            (requireActivity() as MainActivity).isAdd = 1
            (requireActivity() as MainActivity).isMul = 0
            (requireActivity() as MainActivity).isDiv = 0
            (requireActivity() as MainActivity).isMod = 0
            (requireActivity() as MainActivity).isRoot = 0
            (requireActivity() as MainActivity).isMin = 0
            (requireActivity() as MainActivity).isDigit = 0
            (requireActivity() as MainActivity).isDec = 0
            (requireActivity() as MainActivity).numToDiv = 10.0
            (requireActivity() as MainActivity).isSin = 0
            (requireActivity() as MainActivity).isCos = 0
            (requireActivity() as MainActivity).isTan = 0
        }

        btnMin?.setOnClickListener {
            (requireActivity() as MainActivity).isAdd = 0
            (requireActivity() as MainActivity).isMul = 0
            (requireActivity() as MainActivity).isDiv = 0
            (requireActivity() as MainActivity).isMod = 0
            (requireActivity() as MainActivity).isRoot = 0
            (requireActivity() as MainActivity).isMin = 1
            (requireActivity() as MainActivity).isDigit = 0
            (requireActivity() as MainActivity).isDec = 0
            (requireActivity() as MainActivity).numToDiv = 10.0
            (requireActivity() as MainActivity).isSin = 0
            (requireActivity() as MainActivity).isCos = 0
            (requireActivity() as MainActivity).isTan = 0
        }

        btnMul?.setOnClickListener {
            (requireActivity() as MainActivity).isAdd = 0
            (requireActivity() as MainActivity).isMul = 1
            (requireActivity() as MainActivity).isDiv = 0
            (requireActivity() as MainActivity).isMod = 0
            (requireActivity() as MainActivity).isRoot = 0
            (requireActivity() as MainActivity).isMin = 0
            (requireActivity() as MainActivity).isDigit = 0
            (requireActivity() as MainActivity).isDec = 0
            (requireActivity() as MainActivity).numToDiv = 10.0
            (requireActivity() as MainActivity).isSin = 0
            (requireActivity() as MainActivity).isCos = 0
            (requireActivity() as MainActivity).isTan = 0
        }

        btnDiv?.setOnClickListener {
            (requireActivity() as MainActivity).isAdd = 0
            (requireActivity() as MainActivity).isMul = 0
            (requireActivity() as MainActivity).isDiv = 1
            (requireActivity() as MainActivity).isMod = 0
            (requireActivity() as MainActivity).isRoot = 0
            (requireActivity() as MainActivity).isMin = 0
            (requireActivity() as MainActivity).isDigit = 0
            (requireActivity() as MainActivity).isDec = 0
            (requireActivity() as MainActivity).numToDiv = 10.0
            (requireActivity() as MainActivity).isSin = 0
            (requireActivity() as MainActivity).isCos = 0
            (requireActivity() as MainActivity).isTan = 0
        }

        btnMod?.setOnClickListener {
            (requireActivity() as MainActivity).isAdd = 0
            (requireActivity() as MainActivity).isMul = 0
            (requireActivity() as MainActivity).isDiv = 0
            (requireActivity() as MainActivity).isMod = 1
            (requireActivity() as MainActivity).isRoot = 0
            (requireActivity() as MainActivity).isMin = 0
            (requireActivity() as MainActivity).isDigit = 0
            (requireActivity() as MainActivity).isDec = 0
            (requireActivity() as MainActivity).numToDiv = 10.0
            (requireActivity() as MainActivity).isSin = 0
            (requireActivity() as MainActivity).isCos = 0
            (requireActivity() as MainActivity).isTan = 0
        }

        btnRoot?.setOnClickListener {
            (requireActivity() as MainActivity).isAdd = 0
            (requireActivity() as MainActivity).isMul = 0
            (requireActivity() as MainActivity).isDiv = 0
            (requireActivity() as MainActivity).isMod = 0
            (requireActivity() as MainActivity).isRoot = 1
            (requireActivity() as MainActivity).isMin = 0
            (requireActivity() as MainActivity).isDigit = 0
            (requireActivity() as MainActivity).isDec = 0
            (requireActivity() as MainActivity).numToDiv = 10.0
            (requireActivity() as MainActivity).isSin = 0
            (requireActivity() as MainActivity).isCos = 0
            (requireActivity() as MainActivity).isTan = 0
        }


        return view
    }

}
