package com.example.calculator_v2

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.calculator_v2.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    // bidings for UI
    lateinit var binding: ActivityMainBinding

    // vars for the Fragments
    var FragmentTrig = TrigFragment()
    var FragmentBasic = BasicFragment()


    // First and second containers
    var First: Double = 0.0
    var Second: Double = 0.0

    // know if it's a digit
    var isDigit: Int = 0
    var isDec: Int = 0

    var numToDiv: Double = 10.0


    // calcs
    var isMul: Int = 0
    var isAdd: Int = 0
    var isMin: Int = 0
    var isDiv: Int = 0
    var isMod: Int = 0
    var isRoot: Int = 0

    // trig
    var isSin: Int = 0
    var isTan: Int = 0
    var isCos: Int = 0


    fun isFirst (): Int{
        if (isMul == 0 && isAdd == 0 && isMin == 0){
            return 1
        }
        else {
            return 0
        }
    }

    fun addDecimalPoint(numper: Double) {
        if (isFirst() == 1 && isDec == 1){
            First = First + (numper / numToDiv)
            numToDiv = numToDiv * 10.0
            binding.textView.append(numper.toInt().toString())
        }

        if (isFirst() == 0 && isDec == 1){
            Second = Second + (numper / numToDiv)
            numToDiv = numToDiv * 10.0
            binding.textView.append(numper.toInt().toString())
        }
    }


    public override fun onCreate(savedInstanceState: Bundle?) {
        var Result: Double = 0.0

        super.onCreate(savedInstanceState)
        // inflate layout
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        //default fragment

        supportFragmentManager.beginTransaction().apply {
            replace(R.id.Frame1, FragmentBasic)
            commit()
        }

        binding.buttonTrig.setOnClickListener {
            supportFragmentManager.beginTransaction().apply {
                replace(R.id.Frame1, FragmentTrig)
                commit()
            }
        }

        binding.buttonBasic.setOnClickListener {
            supportFragmentManager.beginTransaction().apply {
                replace(R.id.Frame1, FragmentBasic)
                commit()
            }
        }

        // check if the a button was presses and if so, check which var it should go to.
        binding.button1.setOnClickListener {
            if (isFirst() == 1 && isDec == 0){
                if (isDigit == 0) {
                    First = 1.0
                    binding.textView.text = "1"
                    isDigit = 1
                }
                else{
                    First = First * 10 + 1
                    binding.textView.append("1")
                }
            }
            if (isFirst() == 0 && isDec == 0){
                if (isDigit == 0) {
                    Second = 1.0
                    binding.textView.text = "1"
                    isDigit = 1
                }
                else{
                    Second = Second * 10 + 1
                    binding.textView.append("1")
                }
            }
            else{
                addDecimalPoint(1.0)
            }

        }
        binding.button2.setOnClickListener {
            if (isFirst() == 1){
                if (isDigit == 0 && isDec == 0) {
                    First = 2.0
                    binding.textView.text = "2"
                    isDigit = 1
                }
                else{
                    First = First * 10 + 2
                    binding.textView.append("2")
                }
            }
            if (isFirst() == 0){
                if (isDigit == 0 && isDec == 0) {
                    Second = 2.0
                    binding.textView.text = "2"
                    isDigit = 1
                }
                else{
                    Second = Second * 10 + 2
                    binding.textView.append("2")
                }
            }
            else{
                addDecimalPoint(2.0)
            }
        }
        binding.button3.setOnClickListener {
            if (isFirst() == 1 && isDec == 0){
                if (isDigit == 0) {
                    First = 3.0
                    binding.textView.text = "3"
                    isDigit = 1
                }
                else{
                    First = First * 10 + 3
                    binding.textView.append("3")
                }
            }
            if (isFirst() == 0 && isDec == 0){
                if (isDigit == 0) {
                    Second = 3.0
                    binding.textView.text = "3"
                    isDigit = 1
                }
                else{
                    Second = Second * 10 + 3
                    binding.textView.append("3")
                }
            }
            else{
                addDecimalPoint(3.0)
            }
        }
        binding.button4.setOnClickListener {
            if (isFirst() == 1 && isDec == 0){
                if (isDigit == 0) {
                    First = 4.0
                    binding.textView.text = "4"
                    isDigit = 1
                }
                else{
                    First = First * 10 + 4
                    binding.textView.append("4")
                }
            }
            if (isFirst() == 0 && isDec == 0){
                if (isDigit == 0) {
                    Second = 4.0
                    binding.textView.text = "4"
                    isDigit = 1
                }
                else{
                    Second = Second * 10 + 4
                    binding.textView.append("4")
                }
            }
            else{
                addDecimalPoint(4.0)
            }
        }
        binding.button5.setOnClickListener {
            if (isFirst() == 1 && isDec == 0){
                if (isDigit == 0) {
                    First = 5.0
                    binding.textView.text = "5"
                    isDigit = 1
                }
                else{
                    First = First * 10 + 5
                    binding.textView.append("5")
                }
            }
            if (isFirst() == 0 && isDec == 0){
                if (isDigit == 0) {
                    Second = 5.0
                    binding.textView.text = "5"
                    isDigit = 1
                }
                else{
                    Second = Second * 10 + 5
                    binding.textView.append("5")
                }
            }
            else{
                addDecimalPoint(5.0)
            }
        }
        binding.button6.setOnClickListener {
            if (isFirst() == 1 && isDec == 0){
                if (isDigit == 0) {
                    First = 6.0
                    binding.textView.text = "6"
                    isDigit = 1
                }
                else{
                    First = First * 10 + 6
                    binding.textView.append("6")
                }
            }
            if (isFirst() == 0 && isDec == 0){
                if (isDigit == 0) {
                    Second = 6.0
                    binding.textView.text = "6"
                    isDigit = 1
                }
                else{
                    Second = Second * 10 + 6
                    binding.textView.append("6")
                }
            }
            else{
                addDecimalPoint(6.0)
            }
        }
        binding.button7.setOnClickListener {
            if (isFirst() == 1 && isDec == 0){
                if (isDigit == 0) {
                    First = 7.0
                    binding.textView.text = "7"
                    isDigit = 1
                }
                else{
                    First = First * 10 + 7
                    binding.textView.append("7")
                }
            }
            if (isFirst() == 0 && isDec == 0){
                if (isDigit == 0) {
                    Second = 7.0
                    binding.textView.text = "7"
                    isDigit = 1
                }
                else{
                    Second = Second * 10 + 7
                    binding.textView.append("7")
                }
            }
            else{
                addDecimalPoint(7.0)
            }
        }
        binding.button8.setOnClickListener {
            if (isFirst() == 1 && isDec == 0){
                if (isDigit == 0) {
                    First = 8.0
                    binding.textView.text = "8"
                    isDigit = 1
                }
                else{
                    First = First * 10 + 8
                    binding.textView.append("8")
                }
            }
            if (isFirst() == 0 && isDec == 0){
                if (isDigit == 0) {
                    Second = 8.0
                    binding.textView.text = "8"
                    isDigit = 1
                }
                else{
                    Second = Second * 10 + 8
                    binding.textView.append("8")
                }
            }
            else{
                addDecimalPoint(8.0)
            }
        }
        binding.button9.setOnClickListener {
            if (isFirst() == 1 && isDec == 0){
                if (isDigit == 0) {
                    First = 9.0
                    binding.textView.text = "9"
                    isDigit = 1
                }
                else{
                    First = First * 10 + 9
                    binding.textView.append("9")
                }
            }
            if (isFirst() == 0 && isDec == 0){
                if (isDigit == 0) {
                    Second = 9.0
                    binding.textView.text = "9"
                    isDigit = 1
                }
                else{
                    Second = Second * 10 + 9
                    binding.textView.append("9")
                }
            }
            else{
                addDecimalPoint(9.0)
            }
        }
        binding.button0.setOnClickListener {
            if (isFirst() == 1 && isDec == 0){
                if (isDigit == 0) {
                    First = 0.0
                    binding.textView.text = "0"
                    isDigit = 1
                }
                else{
                    First = First * 10 + 0
                    binding.textView.append("0")
                }
            }
            if (isFirst() == 0 && isDec == 0){
                if (isDigit == 0) {
                    Second = 0.0
                    binding.textView.text = "0"
                    isDigit = 1
                }
                else{
                    Second = Second * 10 + 0
                    binding.textView.append("0")
                }
            }
            else{
                addDecimalPoint(0.0)
            }
        }

        binding.buttonDecimal.setOnClickListener {
            if (isFirst() == 1 && isDec == 0){
                isDec = 1
                binding.textView.append(".")
            }

            if (isFirst() == 0 && isDec == 0){
                isDec = 1
                binding.textView.append(".")
            }

        }

        // do the calculations once the equals button is pressed
        binding.buttonEqual.setOnClickListener {
            // check which calculation to perform
            if (isAdd == 1){
                Result = First + Second
                if (isDec == 1) {
                    binding.textView.text = Result.toString()
                }
                if (isDec == 0) {
                    binding.textView.text = Result.toInt().toString()
                }
            }
            if (isMul == 1){
                Result = First * Second
                if (isDec == 1) {
                    binding.textView.text = Result.toString()
                }
                if (isDec == 0) {
                    binding.textView.text = Result.toInt().toString()
                }
            }
            if (isMin == 1){
                Result = First - Second
                if (isDec == 1) {
                    binding.textView.text = Result.toString()
                }
                if (isDec == 0) {
                    binding.textView.text = Result.toInt().toString()
                }
            }
            if (isMod == 1){
                Result = First % Second
                if (isDec == 1) {
                    binding.textView.text = Result.toString()
                }
                if (isDec == 0) {
                    binding.textView.text = Result.toInt().toString()
                }
            }
            if (isDiv == 1){
                Result = First.div(Second)
                if (isDec == 1) {
                    binding.textView.text = Result.toString()
                }
                if (isDec == 0) {
                    binding.textView.text = Result.toInt().toString()
                }
            }
            if (isRoot == 1){
                Result = Math.sqrt(First)
                if (isDec == 1) {
                    binding.textView.text = Result.toString()
                }
                if (isDec == 0) {
                    binding.textView.text = Result.toInt().toString()
                }
            }
            if (isSin == 1){
                Result = Math.asin(First) / Math.PI * 180
                isDec = 1
                if (isDec == 1) {
                    binding.textView.text = Result.toString()
                }
                if (isDec == 0) {
                    binding.textView.text = Result.toInt().toString()
                }
            }
            if (isCos == 1){
                Result = Math.acos(First) / Math.PI * 180
                isDec = 1
                if (isDec == 1) {
                    binding.textView.text = Result.toString()
                }
                if (isDec == 0) {
                    binding.textView.text = Result.toInt().toString()
                }
            }
            if (isTan == 1){
                Result = Math.atan(First) / Math.PI * 180
                isDec = 1
                if (isDec == 1) {
                    binding.textView.text = Result.toString()
                }
                if (isDec == 0) {
                    binding.textView.text = Result.toInt().toString()
                }
            }

            // clear the registers for the calculation states
            isAdd = 0
            isMin = 0
            isMul = 0
            isDigit = 0

            // has an ans feature
            First = Result
        }

        // clear the registers and start a fresh
        binding.buttonClear.setOnClickListener {
            binding.textView.text = "0"
            isAdd = 0
            isMin = 0
            isMul = 0
            isMod = 0
            isDiv = 0
            isSin = 0
            isCos = 0
            isTan = 0
            isRoot = 0
            First = 0.0
            Second = 0.0
            Result = 0.0
            isDigit = 0

        }


    }

    }
